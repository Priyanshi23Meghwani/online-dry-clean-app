function CancelOrder(){
    return(
        <div>
            Update order status to requested to cancel if order status is pending.
        </div>
    )
}

export default CancelOrder;